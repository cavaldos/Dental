const lichhen = [
  {
    MANS: "NS0006",
    TENNS: "Hoàng Thị Ngọc Anh",
    SOTT: 1,
    NGAY: "2024-01-01T00:00:00.000Z",
    GIOBATDAU: "1970-01-01T17:00:00.000Z",
    GIOKETTHUC: "1970-01-01T19:00:00.000Z",
    MACA: "CA005",
    LYDOKHAM:
      "Người thân tôi nói rằng tôi kêu răng khi ngủ, và tôi muốn kiểm tra xem có vấn đề gì về nha khoa gây ra điều này\n.",
  },
  {
    MANS: "NS0006",
    TENNS: "Hoàng Thị Ngọc Anh",
    SOTT: 1,
    NGAY: "2023-01-01T00:00:00.000Z",
    GIOBATDAU: "1970-01-01T17:00:00.000Z",
    GIOKETTHUC: "1970-01-01T19:00:00.000Z",
    MACA: "CA004",
    LYDOKHAM: "Trám răng",
  },
  {
    MANS: "NS0006",
    TENNS: "Hoàng Thị Ngọc Anh",
    SOTT: 1,
    NGAY: "2024-01-01T00:00:00.000Z",
    GIOBATDAU: "1970-01-01T17:00:00.000Z",
    GIOKETTHUC: "1970-01-01T19:00:00.000Z",
    MACA: "CA004",
    LYDOKHAM:
      "Người thân tôi nói rằng tôi kêu răng khi ngủ, và tôi muốn kiểm tra xem có vấn đề gì về nha khoa gây ra điều này.",
  },
  {
    MANS: "NS0006",
    TENNS: "Hoàng Thị Ngọc Anh",
    SOTT: 1,
    NGAY: "2023-01-01T00:00:00.000Z",
    GIOBATDAU: "1970-01-01T17:00:00.000Z",
    GIOKETTHUC: "1970-01-01T19:00:00.000Z",
    MACA: "CA004",
    LYDOKHAM:
      "Người thân tôi nói rằng tôi kêu răng khi ngủ, và tôi muốn kiểm tra xem có vấn đề gì về nha khoa gây ra điều này.",
  },
  {
    MANS: "NS0006",
    TENNS: "Hoàng Thị Ngọc Anh",
    SOTT: 1,
    NGAY: "2023-01-01T00:00:00.000Z",
    GIOBATDAU: "1970-01-01T17:00:00.000Z",
    GIOKETTHUC: "1970-01-01T19:00:00.000Z",
    MACA: "CA004",
    LYDOKHAM:
      "Người thân tôi nói rằng tôi kêu răng khi ngủ, và tôi muốn kiểm tra xem có vấn đề gì về nha khoa gây ra điều này.",
  },
  {
    MANS: "NS0006",
    TENNS: "Hoàng Thị Ngọc Anh",
    SOTT: 1,
    NGAY: "2023-01-01T00:00:00.000Z",
    GIOBATDAU: "1970-01-01T17:00:00.000Z",
    GIOKETTHUC: "1970-01-01T19:00:00.000Z",
    MACA: "CA004",
    LYDOKHAM:
      "Người thân tôi nói rằng tôi kêu răng khi ngủ, và tôi muốn kiểm tra xem có vấn đề gì về nha khoa gây ra điều này.",
  },
  {
    MANS: "NS0006",
    TENNS: "Hoàng Thị Ngọc Anh",
    SOTT: 1,
    NGAY: "2023-01-01T00:00:00.000Z",
    GIOBATDAU: "1970-01-01T17:00:00.000Z",
    GIOKETTHUC: "1970-01-01T19:00:00.000Z",
    MACA: "CA004",
    LYDOKHAM:
      "Người thân tôi nói rằng tôi kêu răng khi ngủ, và tôi muốn kiểm tra xem có vấn đề gì về nha khoa gây ra điều này.",
  },
  {
    MANS: "NS0006",
    TENNS: "Hoàng Thị Ngọc Anh",
    SOTT: 1,
    NGAY: "2023-01-01T00:00:00.000Z",
    GIOBATDAU: "1970-01-01T17:00:00.000Z",
    GIOKETTHUC: "1970-01-01T19:00:00.000Z",
    MACA: "CA004",
    LYDOKHAM:
      "Người thân tôi nói rằng tôi kêu răng khi ngủ, và tôi muốn kiểm tra xem có vấn đề gì về nha khoa gây ra điều này.",
  },
  {
    MANS: "NS0006",
    TENNS: "Hoàng Thị Ngọc Anh",
    SOTT: 1,
    NGAY: "2023-01-01T00:00:00.000Z",
    GIOBATDAU: "1970-01-01T17:00:00.000Z",
    GIOKETTHUC: "1970-01-01T19:00:00.000Z",
    MACA: "CA004",
    LYDOKHAM:
      "Người thân tôi nói rằng tôi kêu răng khi ngủ, và tôi muốn kiểm tra xem có vấn đề gì về nha khoa gây ra điều này.",
  },
];

export default lichhen;
