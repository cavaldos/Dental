const hoaDon = [
  {
    HOTENKH: "Hoàng Văn Tùng",
    SODT: "0301234567",
    SOTTHD: 1,
    NGAYXUAT: "11/12/2023",
    TONGCHIPHI: 5028000,
    HOTENNV: "Trần Thị Bảo Trâm",
    DATHANHTOAN: false,
    THUOC: [
      {
        MATHUOC: "MT05",
        TENTHUOC: "Vitamin D",
        SLTHUOC: 2,
        DONVITINH: "Chai ",
        DONGIATHUOC: 14000,
      },
    ],
    DICHVU: [
      {
        MADV: "DV07",
        TENDV: "Chỉnh nha",
        SLDV: 1,
        DONGIADV: 5000000,
      },
    ],
  },
  {
    HOTENKH: "Hoàng Văn Tùng",
    SODT: "0301234567",
    SOTTHD: 2,
    NGAYXUAT: "11/12/2023",
    TONGCHIPHI: 5028000,
    HOTENNV: "Trần Thị Bảo Trâm",
    DATHANHTOAN: false,
    THUOC: [
      {
        MATHUOC: "MT05",
        TENTHUOC: "Vitamin D",
        SLTHUOC: 2,
        DONVITINH: "Chai ",
        DONGIATHUOC: 14000,
      },
    ],
    DICHVU: [
      {
        MADV: "DV07",
        TENDV: "Chỉnh nha",
        SLDV: 1,
        DONGIADV: 5000000,
      },
    ],
  },
];
