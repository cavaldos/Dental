const lichranh = [
  {
    NGAY: "2024-01-01T00:00:00.000Z",
    MACA: ["CA002", "CA003", "CA005", "CA001", "CA004", "CA006"],
    MANS: "NS0001",
    SOTT: 1,
  },
  {
    NGAY: "2024-01-02T00:00:00.000Z",
    MACA: ["CA004", "CA002"],
    MANS: "NS0001",
    SOTT: 3,
  },
  {
    NGAY: "2024-01-03T00:00:00.000Z",
    MACA: ["CA001", "CA005"],
    MANS: "NS0001",
    SOTT: 4,
  },
  {
    NGAY: "2024-01-06T00:00:00.000Z",
    MACA: ["CA005", "CA006"],
    MANS: "NS0003",
    SOTT: 5,
  },
  {
    NGAY: "2024-01-05T00:00:00.000Z",
    MACA: ["CA002"],
    MANS: "NS0004",
    SOTT: 4,
  },
  {
    NGAY: "2024-01-04T00:00:00.000Z",
    MACA: ["CA004", "CA006"],
    MANS: "NS0005",
    SOTT: 1,
  },
  {
    NGAY: "2024-01-04T00:00:00.000Z",
    MACA: ["CA004", "CA006"],
    MANS: "NS0005",
    SOTT: 1,
  },
  {
    NGAY: "2024-01-04T00:00:00.000Z",
    MACA: ["CA004", "CA006"],
    MANS: "NS0005",
    SOTT: 1,
  },
];

export default lichranh;
