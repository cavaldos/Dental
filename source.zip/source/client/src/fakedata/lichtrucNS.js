const lich = [
  {
    lichHen: [
      {
        NGAY: "28/11/2023",
        CA: [
          {
            MACA: "CA001",
            GIOBATDAU: "16:00:00",
            GIOKETTHUC: "18:00:00",
            NHASI: [
              {
                MANS: "NS0004",
                HOTENNS: "Trần Minh Tuấn",
                SODTKH: "0301234567",
                HOTENKH: "Hoàng Văn Tùng",
                SOTTLH: 1,
                LYDOKHAM: "Chiếc răng trước cửa đã bị nứt và tôi cảm thấy đau.",
              },
            ],
          },
        ],
      },
    ],
    lichRanh: [
      {
        NGAY: "28/11/2023",
        CA: [
          {
            MACA: "CA001",
            GIOBATDAU: "16:00:00",
            GIOKETTHUC: "18:00:00",
            NHASI: [
              {
                MANS: "NS0001",
                HOTENNS: "Lê Văn Hòa",
                SOTTLR: 5,
              },
            ],
          },
        ],
      },
    ],
  },
];
