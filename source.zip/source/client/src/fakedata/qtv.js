const qtv = [
    {
        MAQTV: "QTV0003",
        HOTEN: "Võ Diệp Phi Vũ",
        PHAI: "Nam",
        MATKHAU: "B@n4n@&Sm1l3*",
      },
    {
      MAQTV: "QTV0002",
      HOTEN: "Vũ Thành Công",
      PHAI: "Nam",
      MATKHAU: "B@n4n@&Sm1l3*",
    },
    {
      MAQTV: "QTV0001",
      HOTEN: "Nguyễn Ngọc Khánh",
      PHAI: "Nam",
      MATKHAU: "P@rk#J0g$L0v3",
    },
  ];
  
  
  export default qtv