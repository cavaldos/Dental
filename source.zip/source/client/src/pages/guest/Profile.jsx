const EditProfileKH = () => {
    return (
        <div>
            <h1>EditProfileKH</h1>
        </div>
    )
}
export default EditProfileKH