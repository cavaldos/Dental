const GuestPage = () => {
  return (
    <div className="  flex justify-center">
      <h1 className="text-red-800 text-3xl">
        Day la trang danh cho khach hang da dang nhap
      </h1>
    </div>
  );
};

export default GuestPage;
