import { Button, Calendar, Select } from "antd";
import HoSoBenh from "~/components/HoSoBenh";
import React, { useState } from "react";
import HoaDon from "~/components/HoaDon";
const DentistPage = () => {
  return <></>;
};
export default DentistPage;
