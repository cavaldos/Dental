

const StaffPage = () => {
  return (
    <div className=" khanh flex justify-center bg-slate-50 h-60 align-middle items-center ">
      <h1>hello</h1>
    </div>
  );
};

export default StaffPage;
