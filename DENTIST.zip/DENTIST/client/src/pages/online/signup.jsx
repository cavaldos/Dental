
const SignUpPage = () => {
  return (
    <div className=" w-full h-[100vh] flex">
      <div className="w-[400px] h-[500px]  bg-red-300 flex justify-center mx-auto  my-auto items-center">
        <h1 className=" text-3xl">Signup</h1>
      </div>
    </div>
  );
};
export default SignUpPage;
