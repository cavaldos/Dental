const HoSoBenh = () => {
  return (
    <div>
      <h1>HoSoBenh</h1>
    </div>
  );
};
export default HoSoBenh;
