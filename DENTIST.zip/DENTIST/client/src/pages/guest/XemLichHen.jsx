const XemLichHen = () => {
  return (
    <>
      <h1>Xem hẹn</h1>
    </>
  );
};
export default XemLichHen;
