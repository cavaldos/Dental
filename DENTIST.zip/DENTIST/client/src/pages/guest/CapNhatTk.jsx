const CapNhatTaiKhoan = () => {
  return (
    <>
      <h1>Đặt lịch hẹn</h1>
    </>
  );
};
export default CapNhatTaiKhoan;
