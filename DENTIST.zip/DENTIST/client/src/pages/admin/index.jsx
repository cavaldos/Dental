const AdminPage = () => {
  return (
    <div>
      <h1 className="text-red-800 mr-auto text-lg">Admin Page</h1>

    </div>
  );
};

export default AdminPage;
