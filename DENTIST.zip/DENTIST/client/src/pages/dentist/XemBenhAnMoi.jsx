const XemBenhAnMoi = () => {
  return (
    <>
      <div>
        <h1>Xem Benh An Moi</h1>
      </div>
    </>
  );
};
export default XemBenhAnMoi;
