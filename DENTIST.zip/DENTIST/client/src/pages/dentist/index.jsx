const DentistPage = () => {
  return (
    <div className="  flex justify-center bg-slate-50 h-60 align-middle items-center ">
      <h1 className="text-3xl">Trang dành cho Nha Sĩ</h1>
    </div>
  );
};

export default DentistPage;
