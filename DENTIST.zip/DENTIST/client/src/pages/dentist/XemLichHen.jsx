const XemLichHen = () => {
  return (
    <>
      <div>
        <h1>Xem Lịch Hẹn</h1>
      </div>
    </>
  );
};
export default XemLichHen;
