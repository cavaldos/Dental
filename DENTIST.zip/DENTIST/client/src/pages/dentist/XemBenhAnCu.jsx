const XemBenhAnCu = () => {
  return (
    <>
      <div>
        <h1>Xem Benh An Cu</h1>
      </div>
    </>
  );
};
export default XemBenhAnCu;
