const XemLichTruc = () => {
  return (
    <>
      <div className="  w-full">
        <h1>Xem Lich truc</h1>
      </div>
    </>
  );
};
export default XemLichTruc;
