import OnlineRouter from "./online";
import AdminRouter from "./qtv";
import GuestRouter from "./khachhang";
import StaffRouter from "./nhanvien";
import DentistRouter from "./nhasi";

export { OnlineRouter, AdminRouter, GuestRouter, StaffRouter, DentistRouter };
